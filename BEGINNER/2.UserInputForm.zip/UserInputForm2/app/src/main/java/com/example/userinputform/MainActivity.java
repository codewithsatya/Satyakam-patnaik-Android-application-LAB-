package com.example.userinputform;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private EditText etUserName, etPassword, etAddress, etAge;
    private RadioGroup rgGender;
    private RadioButton rbMale, rbFemale;
    private Spinner spinnerState;
    private Button btnDatePicker, btnSubmit;
    private TextView tvSelectedDate, tvResult;
    private String selectedDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        etUserName = findViewById(R.id.etUserName);
        etPassword = findViewById(R.id.etPassword);
        etAddress = findViewById(R.id.etAddress);
        etAge = findViewById(R.id.etAge);
        rgGender = findViewById(R.id.rgGender);
        rbMale = findViewById(R.id.rbMale);
        rbFemale = findViewById(R.id.rbFemale);
        spinnerState = findViewById(R.id.spinnerState);
        btnDatePicker = findViewById(R.id.btnDatePicker);
        btnSubmit = findViewById(R.id.btnSubmit);
        tvSelectedDate = findViewById(R.id.tvSelectedDate);
        tvResult = findViewById(R.id.tvResult);

        // Setup Spinner for States
        String[] states = {"Select State", "California", "Texas", "Florida", "New York", "Washington", "New Delhi", "Mumbai", "Karnataka"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, states);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerState.setAdapter(adapter);

        // Date Picker Dialog
        btnDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                        (view, year1, monthOfYear, dayOfMonth) -> {
                            selectedDate = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year1;
                            tvSelectedDate.setText(selectedDate);
                        }, year, month, day);
                datePickerDialog.show();
            }
        });

        // Submit Button Click
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitForm();
            }
        });
    }

    private void submitForm() {
        String name = etUserName.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String address = etAddress.getText().toString().trim();
        String age = etAge.getText().toString().trim();
        String state = spinnerState.getSelectedItem().toString();

        int selectedId = rgGender.getCheckedRadioButtonId();
        String gender = "";
        if (selectedId == R.id.rbMale) {
            gender = "Male";
        } else if (selectedId == R.id.rbFemale) {
            gender = "Female";
        }

        if (name.isEmpty() || password.isEmpty() || address.isEmpty() || age.isEmpty() || gender.isEmpty() || state.equals("Select State") || selectedDate.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        String result = "Submitted Data:\n\n" +
                "User Name: " + name + "\n" +
                "Password: " + password + "\n" +
                "Address: " + address + "\n" +
                "Gender: " + gender + "\n" +
                "Age: " + age + "\n" +
                "Date of Birth: " + selectedDate + "\n" +
                "State: " + state;

        tvResult.setText(result);
    }
}
